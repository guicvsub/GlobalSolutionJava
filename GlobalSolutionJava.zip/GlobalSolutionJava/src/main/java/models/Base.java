/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author gui
 */
public abstract class Base {
  
    public void salvar() {
        System.out.println("Entidade salva!");
    }

    public void atualizar() {
        System.out.println("Entidade atualizada!");
    }

    public void deletar() {
        System.out.println("Entidade deletada!");
    }
}
